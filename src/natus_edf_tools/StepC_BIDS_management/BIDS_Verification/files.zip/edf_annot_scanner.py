#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
edf_annot_scanner.py

Core scanning and processing logic for EDF annotation extraction.
Handles folder traversal, file processing, TSV output, and logging.

Author: Claude (based on patterns from Nasim's annotation tools)
"""

from __future__ import annotations

import os
import csv
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Callable, Dict, Any
from datetime import datetime

from edf_annot_utils import (
    onset_to_seconds,
    format_onset_hhmmss,
    sanitize_for_tsv,
    get_relative_path,
    create_output_path,
    ensure_directory,
    setup_logger,
    format_file_size,
    get_timestamp,
)
from edf_annot_reader import (
    EDFAnnotationReader,
    AnnotationReadResult,
    EDFAnnotation,
    EDFFileInfo,
    read_edf_annotations,
)


@dataclass
class FileResult:
    """Result of processing a single EDF file."""
    input_path: str
    relative_path: str
    output_path: Optional[str]
    file_info: Optional[EDFFileInfo]
    total_annotations: int
    non_empty_annotations: int
    empty_annotations: int
    extracted_count: int
    has_content: bool
    error: Optional[str]
    success: bool
    processing_time_ms: float


@dataclass
class ScanSummary:
    """Summary of the entire scan operation."""
    input_folder: str
    output_folder: str
    log_file: str
    start_time: datetime
    end_time: Optional[datetime]
    total_files_found: int
    files_processed: int
    files_with_annotations: int
    files_with_non_empty_annotations: int
    files_without_annotations: int
    files_with_errors: int
    total_annotations_found: int
    total_non_empty_annotations: int
    total_extracted: int
    file_results: List[FileResult] = field(default_factory=list)
    
    def elapsed_seconds(self) -> float:
        if self.end_time is None:
            return 0.0
        return (self.end_time - self.start_time).total_seconds()


class EDFAnnotationScanner:
    """
    Scanner for extracting annotations from EDF files in a folder tree.
    """
    
    def __init__(
        self,
        input_folder: str,
        output_folder: str,
        max_annotations: int = 20,
        log_file: Optional[str] = None,
        progress_callback: Optional[Callable[[int, int, str], None]] = None,
    ):
        """
        Initialize the scanner.
        
        Args:
            input_folder: Root folder to scan for EDF files
            output_folder: Root folder for output TSV files
            max_annotations: Maximum annotations to extract per file (default 20)
            log_file: Path to log file (auto-generated if None)
            progress_callback: Optional callback(current, total, message) for progress updates
        """
        self.input_folder = os.path.abspath(input_folder)
        self.output_folder = os.path.abspath(output_folder)
        self.max_annotations = max_annotations
        self.progress_callback = progress_callback
        
        # Set up log file
        if log_file is None:
            timestamp = get_timestamp()
            log_file = os.path.join(output_folder, f"scan_log_{timestamp}.txt")
        self.log_file = log_file
        
        # Logger will be set up when scan starts
        self.logger: Optional[logging.Logger] = None
        
        # Results
        self.summary: Optional[ScanSummary] = None
        self._cancelled = False
    
    def cancel(self):
        """Cancel the scan operation."""
        self._cancelled = True
    
    def scan(self) -> ScanSummary:
        """
        Execute the scan operation.
        
        Returns:
            ScanSummary with all results
        """
        self._cancelled = False
        
        # Initialize summary
        self.summary = ScanSummary(
            input_folder=self.input_folder,
            output_folder=self.output_folder,
            log_file=self.log_file,
            start_time=datetime.now(),
            end_time=None,
            total_files_found=0,
            files_processed=0,
            files_with_annotations=0,
            files_with_non_empty_annotations=0,
            files_without_annotations=0,
            files_with_errors=0,
            total_annotations_found=0,
            total_non_empty_annotations=0,
            total_extracted=0,
        )
        
        # Set up logging
        ensure_directory(self.log_file)
        self.logger = setup_logger(self.log_file)
        
        self._log_header()
        
        try:
            # Find all EDF files
            edf_files = self._find_edf_files()
            self.summary.total_files_found = len(edf_files)
            
            self.logger.info(f"Found {len(edf_files)} EDF/BDF files to process")
            self._update_progress(0, len(edf_files), "Starting scan...")
            
            # Process each file
            for i, edf_path in enumerate(edf_files):
                if self._cancelled:
                    self.logger.warning("Scan cancelled by user")
                    break
                
                rel_path = get_relative_path(edf_path, self.input_folder)
                self._update_progress(i + 1, len(edf_files), f"Processing: {rel_path}")
                
                result = self._process_file(edf_path)
                self.summary.file_results.append(result)
                self._update_summary(result)
                
                self.summary.files_processed = i + 1
            
            self.summary.end_time = datetime.now()
            self._log_summary()
            
        except Exception as e:
            self.logger.error(f"Fatal error during scan: {e}")
            self.summary.end_time = datetime.now()
            raise
        
        return self.summary
    
    def _find_edf_files(self) -> List[str]:
        """
        Find all EDF/BDF files in the input folder recursively.
        
        Returns:
            List of absolute file paths
        """
        edf_files = []
        
        for root, dirs, files in os.walk(self.input_folder):
            # Skip hidden directories
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            
            for filename in files:
                lower_name = filename.lower()
                if lower_name.endswith('.edf') or lower_name.endswith('.bdf'):
                    full_path = os.path.join(root, filename)
                    edf_files.append(full_path)
        
        # Sort for consistent ordering
        edf_files.sort()
        
        return edf_files
    
    def _process_file(self, file_path: str) -> FileResult:
        """
        Process a single EDF file.
        
        Args:
            file_path: Path to the EDF file
            
        Returns:
            FileResult with processing outcome
        """
        import time
        start_time = time.time()
        
        rel_path = get_relative_path(file_path, self.input_folder)
        
        self.logger.info(f"Processing: {rel_path}")
        
        try:
            # Read annotations
            result = read_edf_annotations(file_path, max_annotations=-1)  # Read all to count
            
            if not result.success:
                self.logger.warning(f"  Error reading file: {result.error}")
                elapsed_ms = (time.time() - start_time) * 1000
                return FileResult(
                    input_path=file_path,
                    relative_path=rel_path,
                    output_path=None,
                    file_info=result.file_info,
                    total_annotations=0,
                    non_empty_annotations=0,
                    empty_annotations=0,
                    extracted_count=0,
                    has_content=False,
                    error=result.error,
                    success=False,
                    processing_time_ms=elapsed_ms,
                )
            
            file_info = result.file_info
            
            # Log file details
            self._log_file_details(file_info, result)
            
            # Check if there are non-empty annotations
            non_empty = result.non_empty_annotations
            
            if not non_empty:
                self.logger.info(f"  No non-empty annotations found")
                elapsed_ms = (time.time() - start_time) * 1000
                return FileResult(
                    input_path=file_path,
                    relative_path=rel_path,
                    output_path=None,
                    file_info=file_info,
                    total_annotations=result.total_annotation_count,
                    non_empty_annotations=0,
                    empty_annotations=result.empty_count,
                    extracted_count=0,
                    has_content=False,
                    error=None,
                    success=True,
                    processing_time_ms=elapsed_ms,
                )
            
            # Extract first N non-empty annotations
            to_extract = non_empty[:self.max_annotations]
            
            # Create output path
            output_path = create_output_path(
                file_path, self.input_folder, self.output_folder, "_annot.tsv"
            )
            
            # Write TSV
            self._write_tsv(output_path, to_extract, file_info)
            
            self.logger.info(f"  Extracted {len(to_extract)} annotations to: {get_relative_path(output_path, self.output_folder)}")
            
            elapsed_ms = (time.time() - start_time) * 1000
            return FileResult(
                input_path=file_path,
                relative_path=rel_path,
                output_path=output_path,
                file_info=file_info,
                total_annotations=result.total_annotation_count,
                non_empty_annotations=result.non_empty_count,
                empty_annotations=result.empty_count,
                extracted_count=len(to_extract),
                has_content=True,
                error=None,
                success=True,
                processing_time_ms=elapsed_ms,
            )
            
        except Exception as e:
            self.logger.error(f"  Exception processing file: {e}")
            elapsed_ms = (time.time() - start_time) * 1000
            return FileResult(
                input_path=file_path,
                relative_path=rel_path,
                output_path=None,
                file_info=None,
                total_annotations=0,
                non_empty_annotations=0,
                empty_annotations=0,
                extracted_count=0,
                has_content=False,
                error=str(e),
                success=False,
                processing_time_ms=elapsed_ms,
            )
    
    def _log_file_details(self, file_info: EDFFileInfo, result: AnnotationReadResult):
        """Log detailed information about a file."""
        self.logger.debug(f"  File size: {format_file_size(file_info.file_size)}")
        self.logger.debug(f"  Format: {file_info.version} (EDF+={file_info.is_edfplus}, BDF+={file_info.is_bdfplus})")
        self.logger.debug(f"  Patient: {file_info.patient_id}")
        self.logger.debug(f"  Recording: {file_info.recording_id}")
        self.logger.debug(f"  Start: {file_info.start_date} {file_info.start_time}")
        self.logger.debug(f"  Duration: {file_info.total_duration_seconds:.2f}s")
        self.logger.debug(f"  Signals: {file_info.num_signals}")
        self.logger.debug(f"  Has annotation channel: {file_info.has_annotation_channel}")
        self.logger.info(f"  Total annotations: {result.total_annotation_count} (non-empty: {result.non_empty_count}, empty: {result.empty_count})")
    
    def _write_tsv(self, output_path: str, annotations: List[EDFAnnotation], file_info: EDFFileInfo):
        """
        Write annotations to a TSV file.
        
        Args:
            output_path: Path to output TSV file
            annotations: List of annotations to write
            file_info: File information for header comments
        """
        ensure_directory(output_path)
        
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            # Write header comments
            f.write(f"# Source file: {file_info.path}\n")
            f.write(f"# File format: {file_info.version}\n")
            f.write(f"# Patient: {file_info.patient_id}\n")
            f.write(f"# Recording: {file_info.recording_id}\n")
            f.write(f"# Start: {file_info.start_date} {file_info.start_time}\n")
            f.write(f"# Duration: {file_info.total_duration_seconds:.2f}s\n")
            f.write(f"# Extracted: {datetime.now().isoformat()}\n")
            f.write(f"# Max annotations: {self.max_annotations}\n")
            f.write("#\n")
            
            # Write TSV with headers
            writer = csv.writer(f, delimiter='\t', quoting=csv.QUOTE_MINIMAL)
            
            # Header row
            writer.writerow([
                'index',
                'onset_raw',
                'onset_seconds', 
                'onset_hhmmss',
                'duration_raw',
                'duration_seconds',
                'description',
                'description_normalized',
                'block_position',
            ])
            
            # Data rows
            for i, annot in enumerate(annotations):
                onset_hhmmss = format_onset_hhmmss(annot.onset_seconds)
                dur_str = f"{annot.duration_seconds:.6f}" if annot.duration_seconds is not None else ""
                
                writer.writerow([
                    i + 1,
                    annot.onset,
                    f"{annot.onset_seconds:.6f}",
                    onset_hhmmss,
                    annot.duration if annot.duration >= 0 else "",
                    dur_str,
                    sanitize_for_tsv(annot.description),
                    sanitize_for_tsv(annot.description_normalized),
                    annot.block_position,
                ])
    
    def _update_summary(self, result: FileResult):
        """Update summary statistics from a file result."""
        if result.success:
            if result.total_annotations > 0:
                self.summary.files_with_annotations += 1
                self.summary.total_annotations_found += result.total_annotations
                self.summary.total_non_empty_annotations += result.non_empty_annotations
                
                if result.non_empty_annotations > 0:
                    self.summary.files_with_non_empty_annotations += 1
                    self.summary.total_extracted += result.extracted_count
            else:
                self.summary.files_without_annotations += 1
        else:
            self.summary.files_with_errors += 1
    
    def _update_progress(self, current: int, total: int, message: str):
        """Update progress via callback if available."""
        if self.progress_callback:
            self.progress_callback(current, total, message)
    
    def _log_header(self):
        """Log scan header information."""
        self.logger.info("=" * 80)
        self.logger.info("EDF ANNOTATION EXTRACTION SCAN")
        self.logger.info("=" * 80)
        self.logger.info(f"Start time: {self.summary.start_time.isoformat()}")
        self.logger.info(f"Input folder: {self.input_folder}")
        self.logger.info(f"Output folder: {self.output_folder}")
        self.logger.info(f"Max annotations per file: {self.max_annotations}")
        self.logger.info("-" * 80)
    
    def _log_summary(self):
        """Log final summary."""
        self.logger.info("")
        self.logger.info("=" * 80)
        self.logger.info("SCAN SUMMARY")
        self.logger.info("=" * 80)
        self.logger.info(f"End time: {self.summary.end_time.isoformat()}")
        self.logger.info(f"Elapsed time: {self.summary.elapsed_seconds():.2f} seconds")
        self.logger.info("-" * 80)
        self.logger.info(f"Total EDF/BDF files found: {self.summary.total_files_found}")
        self.logger.info(f"Files processed: {self.summary.files_processed}")
        self.logger.info(f"Files with annotation channels: {self.summary.files_with_annotations}")
        self.logger.info(f"Files with non-empty annotations: {self.summary.files_with_non_empty_annotations}")
        self.logger.info(f"Files without annotations: {self.summary.files_without_annotations}")
        self.logger.info(f"Files with errors: {self.summary.files_with_errors}")
        self.logger.info("-" * 80)
        self.logger.info(f"Total annotations found: {self.summary.total_annotations_found}")
        self.logger.info(f"Total non-empty annotations: {self.summary.total_non_empty_annotations}")
        self.logger.info(f"Total annotations extracted: {self.summary.total_extracted}")
        self.logger.info("=" * 80)
        
        # List files with errors
        errors = [r for r in self.summary.file_results if not r.success]
        if errors:
            self.logger.info("")
            self.logger.info("FILES WITH ERRORS:")
            self.logger.info("-" * 80)
            for r in errors:
                self.logger.info(f"  {r.relative_path}")
                self.logger.info(f"    Error: {r.error}")
        
        # List files with non-empty annotations
        with_content = [r for r in self.summary.file_results if r.has_content]
        if with_content:
            self.logger.info("")
            self.logger.info("FILES WITH EXTRACTED ANNOTATIONS:")
            self.logger.info("-" * 80)
            for r in with_content:
                self.logger.info(f"  {r.relative_path}")
                self.logger.info(f"    Total: {r.total_annotations}, Non-empty: {r.non_empty_annotations}, Extracted: {r.extracted_count}")
                self.logger.info(f"    Output: {get_relative_path(r.output_path, self.output_folder)}")
        
        # List files without annotations
        without_annot = [r for r in self.summary.file_results if r.success and not r.has_content]
        if without_annot:
            self.logger.info("")
            self.logger.info("FILES WITHOUT NON-EMPTY ANNOTATIONS:")
            self.logger.info("-" * 80)
            for r in without_annot:
                reason = "no annotation channel" if r.total_annotations == 0 else f"all {r.total_annotations} annotations empty"
                self.logger.info(f"  {r.relative_path} ({reason})")


def scan_folder(
    input_folder: str,
    output_folder: str,
    max_annotations: int = 20,
    log_file: Optional[str] = None,
    progress_callback: Optional[Callable[[int, int, str], None]] = None,
) -> ScanSummary:
    """
    Convenience function to scan a folder for EDF annotations.
    
    Args:
        input_folder: Root folder to scan
        output_folder: Root folder for output
        max_annotations: Maximum annotations per file
        log_file: Optional log file path
        progress_callback: Optional progress callback
        
    Returns:
        ScanSummary with all results
    """
    scanner = EDFAnnotationScanner(
        input_folder=input_folder,
        output_folder=output_folder,
        max_annotations=max_annotations,
        log_file=log_file,
        progress_callback=progress_callback,
    )
    return scanner.scan()
