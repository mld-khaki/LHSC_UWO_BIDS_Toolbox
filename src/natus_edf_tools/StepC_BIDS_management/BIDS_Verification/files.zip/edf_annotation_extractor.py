#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
edf_annotation_extractor.py

Main entry point for EDF annotation extraction tool.
Provides both GUI (Tkinter) and CLI interfaces.

Usage:
    GUI mode (no arguments):
        python edf_annotation_extractor.py
    
    CLI mode:
        python edf_annotation_extractor.py --input /path/to/edf/folder --output /path/to/output
        python edf_annotation_extractor.py -i /path/to/input -o /path/to/output -n 30

Author: Claude (based on patterns from Nasim's annotation tools)
"""

from __future__ import annotations

import argparse
import os
import sys
import threading
from datetime import datetime
from typing import Optional

# Import scanner module
from edf_annot_scanner import EDFAnnotationScanner, ScanSummary, scan_folder
from edf_annot_utils import get_timestamp


def run_cli(args: argparse.Namespace) -> int:
    """
    Run the scanner in CLI mode.
    
    Args:
        args: Parsed command line arguments
        
    Returns:
        Exit code (0 for success)
    """
    input_folder = args.input
    output_folder = args.output
    max_annotations = args.num_annotations
    log_file = args.log
    
    # Validate input
    if not os.path.isdir(input_folder):
        print(f"Error: Input folder does not exist: {input_folder}")
        return 1
    
    # Create output folder if needed
    os.makedirs(output_folder, exist_ok=True)
    
    print("=" * 60)
    print("EDF Annotation Extractor")
    print("=" * 60)
    print(f"Input folder:  {input_folder}")
    print(f"Output folder: {output_folder}")
    print(f"Max annotations per file: {max_annotations}")
    print("-" * 60)
    
    # Progress callback for CLI
    def progress(current: int, total: int, message: str):
        pct = (current / total * 100) if total > 0 else 0
        print(f"[{current}/{total}] ({pct:.1f}%) {message}")
    
    try:
        summary = scan_folder(
            input_folder=input_folder,
            output_folder=output_folder,
            max_annotations=max_annotations,
            log_file=log_file,
            progress_callback=progress,
        )
        
        print("-" * 60)
        print("SCAN COMPLETE")
        print("-" * 60)
        print(f"Files found:              {summary.total_files_found}")
        print(f"Files processed:          {summary.files_processed}")
        print(f"Files with annotations:   {summary.files_with_non_empty_annotations}")
        print(f"Files without content:    {summary.files_without_annotations}")
        print(f"Files with errors:        {summary.files_with_errors}")
        print(f"Total annotations found:  {summary.total_annotations_found}")
        print(f"Annotations extracted:    {summary.total_extracted}")
        print(f"Elapsed time:             {summary.elapsed_seconds():.2f} seconds")
        print(f"Log file:                 {summary.log_file}")
        print("=" * 60)
        
        return 0
        
    except Exception as e:
        print(f"Error: {e}")
        return 1


def run_gui():
    """Run the scanner in GUI mode using Tkinter."""
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    
    class AnnotationExtractorGUI:
        """Tkinter GUI for EDF annotation extraction."""
        
        def __init__(self):
            self.root = tk.Tk()
            self.root.title("EDF Annotation Extractor")
            self.root.geometry("800x650")
            self.root.minsize(700, 550)
            
            # Variables
            self.input_folder = tk.StringVar()
            self.output_folder = tk.StringVar()
            self.max_annotations = tk.IntVar(value=20)
            self.status = tk.StringVar(value="Ready. Select input and output folders.")
            
            # Scanner thread
            self.scanner: Optional[EDFAnnotationScanner] = None
            self.scan_thread: Optional[threading.Thread] = None
            self.is_scanning = False
            
            self._build_ui()
        
        def _build_ui(self):
            """Build the user interface."""
            main_frame = ttk.Frame(self.root, padding="10")
            main_frame.pack(fill=tk.BOTH, expand=True)
            
            # === Input/Output Selection ===
            io_frame = ttk.LabelFrame(main_frame, text="Folders", padding="10")
            io_frame.pack(fill=tk.X, pady=(0, 10))
            
            # Input folder
            ttk.Label(io_frame, text="Input Folder:").grid(row=0, column=0, sticky="w", pady=2)
            ttk.Entry(io_frame, textvariable=self.input_folder, width=60).grid(row=0, column=1, padx=5, pady=2, sticky="ew")
            ttk.Button(io_frame, text="Browse...", command=self._browse_input).grid(row=0, column=2, pady=2)
            
            # Output folder
            ttk.Label(io_frame, text="Output Folder:").grid(row=1, column=0, sticky="w", pady=2)
            ttk.Entry(io_frame, textvariable=self.output_folder, width=60).grid(row=1, column=1, padx=5, pady=2, sticky="ew")
            ttk.Button(io_frame, text="Browse...", command=self._browse_output).grid(row=1, column=2, pady=2)
            
            io_frame.columnconfigure(1, weight=1)
            
            # === Options ===
            opts_frame = ttk.LabelFrame(main_frame, text="Options", padding="10")
            opts_frame.pack(fill=tk.X, pady=(0, 10))
            
            ttk.Label(opts_frame, text="Max annotations per file:").grid(row=0, column=0, sticky="w")
            max_spin = ttk.Spinbox(opts_frame, from_=1, to=1000, textvariable=self.max_annotations, width=10)
            max_spin.grid(row=0, column=1, padx=5, sticky="w")
            
            # === Control Buttons ===
            btn_frame = ttk.Frame(main_frame)
            btn_frame.pack(fill=tk.X, pady=(0, 10))
            
            self.run_btn = ttk.Button(btn_frame, text="Run Scan", command=self._start_scan)
            self.run_btn.pack(side=tk.LEFT, padx=5)
            
            self.cancel_btn = ttk.Button(btn_frame, text="Cancel", command=self._cancel_scan, state=tk.DISABLED)
            self.cancel_btn.pack(side=tk.LEFT, padx=5)
            
            ttk.Button(btn_frame, text="Open Output Folder", command=self._open_output).pack(side=tk.RIGHT, padx=5)
            ttk.Button(btn_frame, text="Open Log File", command=self._open_log).pack(side=tk.RIGHT, padx=5)
            
            # === Progress ===
            prog_frame = ttk.LabelFrame(main_frame, text="Progress", padding="10")
            prog_frame.pack(fill=tk.X, pady=(0, 10))
            
            self.progress_bar = ttk.Progressbar(prog_frame, mode='determinate', length=400)
            self.progress_bar.pack(fill=tk.X, pady=(0, 5))
            
            self.progress_label = ttk.Label(prog_frame, textvariable=self.status)
            self.progress_label.pack(fill=tk.X)
            
            # === Results ===
            results_frame = ttk.LabelFrame(main_frame, text="Results", padding="10")
            results_frame.pack(fill=tk.BOTH, expand=True)
            
            # Create notebook for tabs
            self.notebook = ttk.Notebook(results_frame)
            self.notebook.pack(fill=tk.BOTH, expand=True)
            
            # Summary tab
            self.summary_frame = ttk.Frame(self.notebook)
            self.notebook.add(self.summary_frame, text="Summary")
            
            self.summary_text = tk.Text(self.summary_frame, wrap=tk.WORD, height=10)
            summary_scroll = ttk.Scrollbar(self.summary_frame, command=self.summary_text.yview)
            self.summary_text.configure(yscrollcommand=summary_scroll.set)
            self.summary_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            summary_scroll.pack(side=tk.RIGHT, fill=tk.Y)
            
            # Files tab
            self.files_frame = ttk.Frame(self.notebook)
            self.notebook.add(self.files_frame, text="Files")
            
            cols = ("file", "status", "total", "non_empty", "extracted")
            self.files_tree = ttk.Treeview(self.files_frame, columns=cols, show="headings")
            self.files_tree.heading("file", text="File")
            self.files_tree.heading("status", text="Status")
            self.files_tree.heading("total", text="Total")
            self.files_tree.heading("non_empty", text="Non-Empty")
            self.files_tree.heading("extracted", text="Extracted")
            
            self.files_tree.column("file", width=350)
            self.files_tree.column("status", width=80)
            self.files_tree.column("total", width=60)
            self.files_tree.column("non_empty", width=80)
            self.files_tree.column("extracted", width=70)
            
            files_scroll_y = ttk.Scrollbar(self.files_frame, orient=tk.VERTICAL, command=self.files_tree.yview)
            files_scroll_x = ttk.Scrollbar(self.files_frame, orient=tk.HORIZONTAL, command=self.files_tree.xview)
            self.files_tree.configure(yscrollcommand=files_scroll_y.set, xscrollcommand=files_scroll_x.set)
            
            self.files_tree.grid(row=0, column=0, sticky="nsew")
            files_scroll_y.grid(row=0, column=1, sticky="ns")
            files_scroll_x.grid(row=1, column=0, sticky="ew")
            
            self.files_frame.rowconfigure(0, weight=1)
            self.files_frame.columnconfigure(0, weight=1)
            
            # Errors tab
            self.errors_frame = ttk.Frame(self.notebook)
            self.notebook.add(self.errors_frame, text="Errors")
            
            self.errors_text = tk.Text(self.errors_frame, wrap=tk.WORD)
            errors_scroll = ttk.Scrollbar(self.errors_frame, command=self.errors_text.yview)
            self.errors_text.configure(yscrollcommand=errors_scroll.set)
            self.errors_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            errors_scroll.pack(side=tk.RIGHT, fill=tk.Y)
            
            # Store last summary for log access
            self.last_summary: Optional[ScanSummary] = None
        
        def _browse_input(self):
            """Browse for input folder."""
            folder = filedialog.askdirectory(title="Select Input Folder with EDF Files")
            if folder:
                self.input_folder.set(folder)
                # Auto-suggest output folder
                if not self.output_folder.get():
                    self.output_folder.set(os.path.join(folder, "annotations_output"))
        
        def _browse_output(self):
            """Browse for output folder."""
            folder = filedialog.askdirectory(title="Select Output Folder")
            if folder:
                self.output_folder.set(folder)
        
        def _start_scan(self):
            """Start the scan operation in a background thread."""
            input_path = self.input_folder.get().strip()
            output_path = self.output_folder.get().strip()
            
            if not input_path:
                messagebox.showerror("Error", "Please select an input folder.")
                return
            
            if not os.path.isdir(input_path):
                messagebox.showerror("Error", f"Input folder does not exist:\n{input_path}")
                return
            
            if not output_path:
                messagebox.showerror("Error", "Please select an output folder.")
                return
            
            # Create output folder
            try:
                os.makedirs(output_path, exist_ok=True)
            except Exception as e:
                messagebox.showerror("Error", f"Cannot create output folder:\n{e}")
                return
            
            # Clear previous results
            self.summary_text.delete("1.0", tk.END)
            self.errors_text.delete("1.0", tk.END)
            for item in self.files_tree.get_children():
                self.files_tree.delete(item)
            
            # Set up scanner
            self.scanner = EDFAnnotationScanner(
                input_folder=input_path,
                output_folder=output_path,
                max_annotations=self.max_annotations.get(),
                progress_callback=self._on_progress,
            )
            
            # Update UI state
            self.is_scanning = True
            self.run_btn.configure(state=tk.DISABLED)
            self.cancel_btn.configure(state=tk.NORMAL)
            self.progress_bar['value'] = 0
            self.status.set("Starting scan...")
            
            # Run in background thread
            self.scan_thread = threading.Thread(target=self._run_scan_thread)
            self.scan_thread.start()
        
        def _run_scan_thread(self):
            """Background thread for scanning."""
            try:
                summary = self.scanner.scan()
                self.root.after(0, lambda: self._on_scan_complete(summary))
            except Exception as e:
                self.root.after(0, lambda: self._on_scan_error(str(e)))
        
        def _cancel_scan(self):
            """Cancel the running scan."""
            if self.scanner:
                self.scanner.cancel()
                self.status.set("Cancelling...")
        
        def _on_progress(self, current: int, total: int, message: str):
            """Progress callback from scanner (called from background thread)."""
            def update():
                if total > 0:
                    self.progress_bar['value'] = (current / total) * 100
                self.status.set(f"[{current}/{total}] {message}")
            self.root.after(0, update)
        
        def _on_scan_complete(self, summary: ScanSummary):
            """Called when scan completes."""
            self.is_scanning = False
            self.run_btn.configure(state=tk.NORMAL)
            self.cancel_btn.configure(state=tk.DISABLED)
            self.progress_bar['value'] = 100
            
            self.last_summary = summary
            
            # Update status
            self.status.set(f"Complete! Processed {summary.files_processed} files in {summary.elapsed_seconds():.1f}s")
            
            # Populate summary
            self.summary_text.delete("1.0", tk.END)
            self.summary_text.insert(tk.END, "SCAN SUMMARY\n")
            self.summary_text.insert(tk.END, "=" * 50 + "\n\n")
            self.summary_text.insert(tk.END, f"Input folder:  {summary.input_folder}\n")
            self.summary_text.insert(tk.END, f"Output folder: {summary.output_folder}\n")
            self.summary_text.insert(tk.END, f"Log file:      {summary.log_file}\n\n")
            self.summary_text.insert(tk.END, f"Start time:    {summary.start_time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            self.summary_text.insert(tk.END, f"End time:      {summary.end_time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            self.summary_text.insert(tk.END, f"Elapsed:       {summary.elapsed_seconds():.2f} seconds\n\n")
            self.summary_text.insert(tk.END, "-" * 50 + "\n")
            self.summary_text.insert(tk.END, f"Files found:                    {summary.total_files_found}\n")
            self.summary_text.insert(tk.END, f"Files processed:                {summary.files_processed}\n")
            self.summary_text.insert(tk.END, f"Files with annotation channels: {summary.files_with_annotations}\n")
            self.summary_text.insert(tk.END, f"Files with non-empty content:   {summary.files_with_non_empty_annotations}\n")
            self.summary_text.insert(tk.END, f"Files without annotations:      {summary.files_without_annotations}\n")
            self.summary_text.insert(tk.END, f"Files with errors:              {summary.files_with_errors}\n")
            self.summary_text.insert(tk.END, "-" * 50 + "\n")
            self.summary_text.insert(tk.END, f"Total annotations found:        {summary.total_annotations_found}\n")
            self.summary_text.insert(tk.END, f"Non-empty annotations:          {summary.total_non_empty_annotations}\n")
            self.summary_text.insert(tk.END, f"Annotations extracted:          {summary.total_extracted}\n")
            
            # Populate files tree
            for result in summary.file_results:
                status = "OK" if result.success else "ERROR"
                if result.success and not result.has_content:
                    status = "EMPTY"
                
                self.files_tree.insert("", tk.END, values=(
                    result.relative_path,
                    status,
                    result.total_annotations,
                    result.non_empty_annotations,
                    result.extracted_count,
                ))
            
            # Populate errors
            errors = [r for r in summary.file_results if not r.success]
            if errors:
                self.errors_text.insert(tk.END, f"FILES WITH ERRORS ({len(errors)})\n")
                self.errors_text.insert(tk.END, "=" * 50 + "\n\n")
                for r in errors:
                    self.errors_text.insert(tk.END, f"File: {r.relative_path}\n")
                    self.errors_text.insert(tk.END, f"Error: {r.error}\n\n")
            else:
                self.errors_text.insert(tk.END, "No errors encountered.\n")
            
            # Show completion message
            messagebox.showinfo(
                "Scan Complete",
                f"Processed {summary.files_processed} files.\n"
                f"Extracted annotations from {summary.files_with_non_empty_annotations} files.\n"
                f"See log file for details."
            )
        
        def _on_scan_error(self, error: str):
            """Called when scan encounters a fatal error."""
            self.is_scanning = False
            self.run_btn.configure(state=tk.NORMAL)
            self.cancel_btn.configure(state=tk.DISABLED)
            self.status.set(f"Error: {error}")
            
            messagebox.showerror("Scan Error", f"An error occurred:\n{error}")
        
        def _open_output(self):
            """Open the output folder in file manager."""
            output_path = self.output_folder.get().strip()
            if output_path and os.path.isdir(output_path):
                self._open_folder(output_path)
            else:
                messagebox.showwarning("Warning", "Output folder does not exist.")
        
        def _open_log(self):
            """Open the log file."""
            if self.last_summary and self.last_summary.log_file:
                log_path = self.last_summary.log_file
                if os.path.isfile(log_path):
                    self._open_file(log_path)
                else:
                    messagebox.showwarning("Warning", "Log file not found.")
            else:
                messagebox.showwarning("Warning", "No scan has been run yet.")
        
        def _open_folder(self, path: str):
            """Open a folder in the system file manager."""
            import subprocess
            import platform
            
            system = platform.system()
            try:
                if system == "Windows":
                    os.startfile(path)
                elif system == "Darwin":  # macOS
                    subprocess.run(["open", path])
                else:  # Linux
                    subprocess.run(["xdg-open", path])
            except Exception as e:
                messagebox.showerror("Error", f"Could not open folder:\n{e}")
        
        def _open_file(self, path: str):
            """Open a file with the default application."""
            import subprocess
            import platform
            
            system = platform.system()
            try:
                if system == "Windows":
                    os.startfile(path)
                elif system == "Darwin":  # macOS
                    subprocess.run(["open", path])
                else:  # Linux
                    subprocess.run(["xdg-open", path])
            except Exception as e:
                messagebox.showerror("Error", f"Could not open file:\n{e}")
        
        def run(self):
            """Start the GUI main loop."""
            self.root.mainloop()
    
    # Create and run GUI
    app = AnnotationExtractorGUI()
    app.run()


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Extract annotations from EDF/BDF files. "
                    "Runs in GUI mode if no arguments provided.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  GUI mode:
    python edf_annotation_extractor.py
    
  CLI mode:
    python edf_annotation_extractor.py -i /data/edf_files -o /data/output
    python edf_annotation_extractor.py --input ./recordings --output ./annotations -n 30
        """
    )
    
    parser.add_argument(
        '-i', '--input',
        help='Input folder containing EDF/BDF files (recursive scan)',
    )
    parser.add_argument(
        '-o', '--output',
        help='Output folder for TSV files (maintains folder structure)',
    )
    parser.add_argument(
        '-n', '--num-annotations',
        type=int,
        default=20,
        help='Maximum number of annotations to extract per file (default: 20)',
    )
    parser.add_argument(
        '-l', '--log',
        help='Path to log file (auto-generated in output folder if not specified)',
    )
    
    args = parser.parse_args()
    
    # If no input/output specified, run GUI
    if args.input is None or args.output is None:
        if args.input is not None or args.output is not None:
            print("Error: Both --input and --output must be specified for CLI mode.")
            print("Run without arguments for GUI mode.")
            return 1
        
        # GUI mode
        run_gui()
        return 0
    else:
        # CLI mode
        return run_cli(args)


if __name__ == "__main__":
    sys.exit(main())
