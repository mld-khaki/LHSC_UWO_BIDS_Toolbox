#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
edf_annot_reader.py

Lightweight EDF/BDF annotation reader module.
Provides functionality to read annotations from EDF+ and BDF+ files
without loading signal data.

Can use edfreader_mld2 if available, or fall back to direct parsing.

Author: Claude (based on patterns from edfreader by Teunis van Beelen / Milad Khaki)
"""

from __future__ import annotations

import os
import io
from dataclasses import dataclass
from typing import List, Optional, Tuple, Any
from datetime import datetime

from edf_annot_utils import (
    onset_to_seconds,
    duration_to_seconds,
    is_annotation_empty,
    normalize_annotation_text,
    EDFLIB_TIME_DIMENSION,
)


@dataclass
class EDFAnnotation:
    """Represents a single EDF annotation."""
    onset: int              # Raw onset in 100ns units
    onset_seconds: float    # Onset in seconds
    duration: int           # Raw duration in 100ns units (-1 if unspecified)
    duration_seconds: Optional[float]  # Duration in seconds (None if unspecified)
    description: str        # Annotation text
    description_normalized: str  # Normalized annotation text
    is_empty: bool          # Whether the description is effectively empty
    block_position: int     # File position where annotation was found


@dataclass
class EDFFileInfo:
    """Basic EDF file metadata."""
    path: str
    file_size: int
    version: str
    patient_id: str
    recording_id: str
    start_date: str
    start_time: str
    start_datetime: Optional[datetime]
    header_bytes: int
    num_records: int
    duration_of_record: float
    num_signals: int
    total_duration_seconds: float
    is_edf: bool
    is_bdf: bool
    is_edfplus: bool
    is_bdfplus: bool
    has_annotation_channel: bool
    annotation_channel_indices: List[int]


@dataclass
class AnnotationReadResult:
    """Result of reading annotations from an EDF file."""
    file_info: EDFFileInfo
    annotations: List[EDFAnnotation]
    non_empty_annotations: List[EDFAnnotation]
    total_annotation_count: int
    non_empty_count: int
    empty_count: int
    error: Optional[str]
    success: bool


class EDFAnnotationReader:
    """
    Lightweight reader for EDF/BDF annotations.
    Reads only header and annotations, skips signal data.
    """
    
    def __init__(self, file_path: str):
        """
        Initialize reader with file path.
        
        Args:
            file_path: Path to EDF/BDF file
        """
        self.file_path = file_path
        self._file = None
        self._file_info: Optional[EDFFileInfo] = None
        self._annotations: List[EDFAnnotation] = []
        self._error: Optional[str] = None
        
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
    
    def close(self):
        """Close the file handle."""
        if self._file is not None:
            try:
                self._file.close()
            except Exception:
                pass
            self._file = None
    
    def read(self, max_annotations: int = -1) -> AnnotationReadResult:
        """
        Read annotations from the EDF file.
        
        Args:
            max_annotations: Maximum number of annotations to read (-1 for all)
            
        Returns:
            AnnotationReadResult with file info and annotations
        """
        try:
            # First try using edfreader_mld2 if available
            result = self._read_with_edfreader_mld2(max_annotations)
            if result is not None:
                return result
        except ImportError:
            pass
        except Exception as e:
            # If edfreader_mld2 fails, try direct parsing
            pass
        
        # Fall back to direct parsing
        return self._read_direct(max_annotations)
    
    def _read_with_edfreader_mld2(self, max_annotations: int) -> Optional[AnnotationReadResult]:
        """
        Read using edfreader_mld2 library.
        
        Args:
            max_annotations: Maximum annotations to read
            
        Returns:
            AnnotationReadResult or None if library not available
        """
        try:
            # Try to import from same directory or system path
            import sys
            import os
            
            # Add current directory to path if edfreader_mld2 is there
            script_dir = os.path.dirname(os.path.abspath(__file__))
            if script_dir not in sys.path:
                sys.path.insert(0, script_dir)
            
            from edfreader_mld2 import EDFreader, EDFexception
            
            try:
                with EDFreader(self.file_path, read_annotations=True) as edf:
                    # Build file info
                    file_size = os.path.getsize(self.file_path)
                    file_type = edf.getFileType()
                    
                    is_edf = file_type in [0, 1]  # EDF or EDF+
                    is_bdf = file_type in [2, 3]  # BDF or BDF+
                    is_edfplus = file_type == 1
                    is_bdfplus = file_type == 3
                    
                    try:
                        start_dt = edf.getStartDateTime()
                    except Exception:
                        start_dt = None
                    
                    # Get duration
                    try:
                        total_duration = edf.getFileDuration() / EDFLIB_TIME_DIMENSION
                    except Exception:
                        total_duration = 0.0
                    
                    file_info = EDFFileInfo(
                        path=self.file_path,
                        file_size=file_size,
                        version="EDF" if is_edf else "BDF",
                        patient_id=str(edf.getPatient() or edf.getPatientCode() or ""),
                        recording_id=str(edf.getRecording() or ""),
                        start_date=f"{edf.getStartDateDay():02d}.{edf.getStartDateMonth():02d}.{edf.getStartDateYear()}",
                        start_time=f"{edf.getStartTimeHour():02d}.{edf.getStartTimeMinute():02d}.{edf.getStartTimeSecond():02d}",
                        start_datetime=start_dt,
                        header_bytes=0,  # Not easily accessible
                        num_records=edf.getNumDataRecords(),
                        duration_of_record=edf.getLongDataRecordDuration() / EDFLIB_TIME_DIMENSION,
                        num_signals=edf.getNumSignals(),
                        total_duration_seconds=total_duration,
                        is_edf=is_edf,
                        is_bdf=is_bdf,
                        is_edfplus=is_edfplus,
                        is_bdfplus=is_bdfplus,
                        has_annotation_channel=is_edfplus or is_bdfplus,
                        annotation_channel_indices=[],  # Not exposed directly
                    )
                    
                    # Process annotations
                    annotations = []
                    raw_annots = edf.annotationslist
                    
                    count = 0
                    for annot in raw_annots:
                        if max_annotations >= 0 and count >= max_annotations:
                            break
                        
                        onset = annot.onset
                        duration = annot.duration
                        description = annot.description
                        block = annot.block if hasattr(annot, 'block') else 0
                        
                        onset_sec = onset_to_seconds(onset)
                        dur_sec = duration_to_seconds(duration)
                        desc_norm = normalize_annotation_text(description)
                        empty = is_annotation_empty(description)
                        
                        annotations.append(EDFAnnotation(
                            onset=onset,
                            onset_seconds=onset_sec,
                            duration=duration,
                            duration_seconds=dur_sec,
                            description=description,
                            description_normalized=desc_norm,
                            is_empty=empty,
                            block_position=block,
                        ))
                        count += 1
                    
                    # Separate empty and non-empty
                    non_empty = [a for a in annotations if not a.is_empty]
                    empty_count = len([a for a in annotations if a.is_empty])
                    
                    return AnnotationReadResult(
                        file_info=file_info,
                        annotations=annotations,
                        non_empty_annotations=non_empty,
                        total_annotation_count=len(raw_annots),
                        non_empty_count=len(non_empty),
                        empty_count=empty_count,
                        error=None,
                        success=True,
                    )
                    
            except EDFexception as e:
                return AnnotationReadResult(
                    file_info=self._get_basic_file_info(),
                    annotations=[],
                    non_empty_annotations=[],
                    total_annotation_count=0,
                    non_empty_count=0,
                    empty_count=0,
                    error=f"EDFexception: {e}",
                    success=False,
                )
                
        except ImportError:
            return None
        except Exception as e:
            return AnnotationReadResult(
                file_info=self._get_basic_file_info(),
                annotations=[],
                non_empty_annotations=[],
                total_annotation_count=0,
                non_empty_count=0,
                empty_count=0,
                error=f"Error with edfreader_mld2: {e}",
                success=False,
            )
    
    def _read_direct(self, max_annotations: int) -> AnnotationReadResult:
        """
        Read annotations directly by parsing EDF header and annotation channels.
        This is a fallback if edfreader_mld2 is not available.
        
        Args:
            max_annotations: Maximum annotations to read
            
        Returns:
            AnnotationReadResult
        """
        try:
            file_info = self._parse_header()
            
            if not file_info.has_annotation_channel:
                return AnnotationReadResult(
                    file_info=file_info,
                    annotations=[],
                    non_empty_annotations=[],
                    total_annotation_count=0,
                    non_empty_count=0,
                    empty_count=0,
                    error=None,
                    success=True,
                )
            
            annotations = self._parse_annotations(file_info, max_annotations)
            
            non_empty = [a for a in annotations if not a.is_empty]
            empty_count = len([a for a in annotations if a.is_empty])
            
            return AnnotationReadResult(
                file_info=file_info,
                annotations=annotations,
                non_empty_annotations=non_empty,
                total_annotation_count=len(annotations),
                non_empty_count=len(non_empty),
                empty_count=empty_count,
                error=None,
                success=True,
            )
            
        except Exception as e:
            return AnnotationReadResult(
                file_info=self._get_basic_file_info(),
                annotations=[],
                non_empty_annotations=[],
                total_annotation_count=0,
                non_empty_count=0,
                empty_count=0,
                error=f"Parse error: {e}",
                success=False,
            )
    
    def _get_basic_file_info(self) -> EDFFileInfo:
        """Get basic file info without parsing (for error cases)."""
        try:
            file_size = os.path.getsize(self.file_path)
        except Exception:
            file_size = 0
            
        return EDFFileInfo(
            path=self.file_path,
            file_size=file_size,
            version="unknown",
            patient_id="",
            recording_id="",
            start_date="",
            start_time="",
            start_datetime=None,
            header_bytes=0,
            num_records=0,
            duration_of_record=0.0,
            num_signals=0,
            total_duration_seconds=0.0,
            is_edf=False,
            is_bdf=False,
            is_edfplus=False,
            is_bdfplus=False,
            has_annotation_channel=False,
            annotation_channel_indices=[],
        )
    
    def _parse_header(self) -> EDFFileInfo:
        """
        Parse EDF/BDF header to get file information.
        
        Returns:
            EDFFileInfo with parsed metadata
        """
        file_size = os.path.getsize(self.file_path)
        
        with open(self.file_path, 'rb') as f:
            self._file = f
            
            # Read base header (256 bytes)
            header = f.read(256)
            if len(header) < 256:
                raise ValueError("File too small for EDF header")
            
            # Determine file type
            is_edf = header[0] == ord('0')
            is_bdf = (header[0] == 0xFF and 
                      header[1:8] == b'BIOSEMI')
            
            if not is_edf and not is_bdf:
                raise ValueError("Not a valid EDF or BDF file")
            
            # Parse header fields
            version = self._read_ascii(header[0:8])
            patient_id = self._read_ascii(header[8:88])
            recording_id = self._read_ascii(header[88:168])
            start_date = self._read_ascii(header[168:176])
            start_time = self._read_ascii(header[176:184])
            header_bytes = int(self._read_ascii(header[184:192]) or "0")
            reserved = self._read_ascii(header[192:236])
            num_records_str = self._read_ascii(header[236:244])
            try:
                num_records = int(num_records_str)
            except ValueError:
                num_records = -1
            duration_str = self._read_ascii(header[244:252])
            try:
                duration_of_record = float(duration_str)
            except ValueError:
                duration_of_record = 0.0
            num_signals = int(self._read_ascii(header[252:256]) or "0")
            
            # Determine EDF+/BDF+ from reserved field
            is_edfplus = is_edf and ('EDF+C' in reserved or 'EDF+D' in reserved)
            is_bdfplus = is_bdf and ('BDF+C' in reserved or 'BDF+D' in reserved)
            
            # Read signal headers to find annotation channels
            signal_labels = []
            for i in range(num_signals):
                label_bytes = f.read(16)
                label = self._read_ascii(label_bytes)
                signal_labels.append(label)
            
            # Find annotation channels
            annot_indices = []
            for i, label in enumerate(signal_labels):
                if 'EDF Annotations' in label or 'BDF Annotations' in label:
                    annot_indices.append(i)
            
            has_annotation_channel = len(annot_indices) > 0
            
            # Parse start datetime
            start_datetime = self._parse_datetime(start_date, start_time)
            
            # Calculate total duration
            if num_records > 0:
                total_duration = num_records * duration_of_record
            else:
                total_duration = 0.0
            
            self._file = None
            
            return EDFFileInfo(
                path=self.file_path,
                file_size=file_size,
                version="EDF" if is_edf else "BDF",
                patient_id=patient_id,
                recording_id=recording_id,
                start_date=start_date,
                start_time=start_time,
                start_datetime=start_datetime,
                header_bytes=header_bytes,
                num_records=num_records,
                duration_of_record=duration_of_record,
                num_signals=num_signals,
                total_duration_seconds=total_duration,
                is_edf=is_edf,
                is_bdf=is_bdf,
                is_edfplus=is_edfplus,
                is_bdfplus=is_bdfplus,
                has_annotation_channel=has_annotation_channel,
                annotation_channel_indices=annot_indices,
            )
    
    def _parse_annotations(self, file_info: EDFFileInfo, max_annotations: int) -> List[EDFAnnotation]:
        """
        Parse annotations from the annotation channels.
        This is a simplified parser for basic extraction.
        
        Args:
            file_info: Parsed file info with annotation channel indices
            max_annotations: Maximum annotations to read
            
        Returns:
            List of parsed annotations
        """
        annotations = []
        
        if not file_info.annotation_channel_indices:
            return annotations
        
        sample_size = 2 if file_info.is_edf else 3
        
        with open(self.file_path, 'rb') as f:
            # Skip to signal headers to get samples per record
            f.seek(256 + file_info.num_signals * 16)  # Skip labels
            f.seek(file_info.num_signals * 80, io.SEEK_CUR)  # Skip transducers
            f.seek(file_info.num_signals * 8, io.SEEK_CUR)   # Skip phys dim
            f.seek(file_info.num_signals * 8, io.SEEK_CUR)   # Skip phys min
            f.seek(file_info.num_signals * 8, io.SEEK_CUR)   # Skip phys max
            f.seek(file_info.num_signals * 8, io.SEEK_CUR)   # Skip dig min
            f.seek(file_info.num_signals * 8, io.SEEK_CUR)   # Skip dig max
            f.seek(file_info.num_signals * 80, io.SEEK_CUR)  # Skip prefilter
            
            # Read samples per record for each signal
            samples_per_record = []
            for i in range(file_info.num_signals):
                spr_bytes = f.read(8)
                spr = int(self._read_ascii(spr_bytes) or "0")
                samples_per_record.append(spr)
            
            # Calculate record size and annotation channel offset
            record_size = sum(spr * sample_size for spr in samples_per_record)
            
            # Calculate offset to annotation channel within record
            annot_offsets = []
            for annot_idx in file_info.annotation_channel_indices:
                offset = sum(samples_per_record[i] * sample_size for i in range(annot_idx))
                size = samples_per_record[annot_idx] * sample_size
                annot_offsets.append((offset, size))
            
            # Seek to data section
            f.seek(file_info.header_bytes)
            
            # Read annotations from each data record
            count = 0
            for record in range(file_info.num_records):
                if max_annotations >= 0 and count >= max_annotations:
                    break
                
                record_start = file_info.header_bytes + record * record_size
                
                for annot_offset, annot_size in annot_offsets:
                    if max_annotations >= 0 and count >= max_annotations:
                        break
                    
                    f.seek(record_start + annot_offset)
                    annot_data = f.read(annot_size)
                    
                    # Parse TALs (Time-stamped Annotation Lists)
                    parsed = self._parse_tal(annot_data, record_start + annot_offset)
                    
                    for annot in parsed:
                        if max_annotations >= 0 and count >= max_annotations:
                            break
                        annotations.append(annot)
                        count += 1
        
        return annotations
    
    def _parse_tal(self, data: bytes, position: int) -> List[EDFAnnotation]:
        """
        Parse a Time-stamped Annotation List from annotation channel data.
        
        TAL format:
        +/-onset (21) (20) annotation (20) [annotation (20) ...] (0)
        
        Where:
        - onset is in seconds with optional decimal
        - 21 (0x15) separates duration from onset
        - 20 (0x14) separates annotations
        - 0 (0x00) ends the TAL
        
        Args:
            data: Raw annotation channel data
            position: File position for reference
            
        Returns:
            List of parsed annotations
        """
        annotations = []
        
        i = 0
        while i < len(data):
            # Skip null bytes
            while i < len(data) and data[i] == 0:
                i += 1
            
            if i >= len(data):
                break
            
            # Expect onset starting with + or -
            if data[i] not in [ord('+'), ord('-')]:
                i += 1
                continue
            
            # Find end of onset (0x14 or 0x15)
            onset_start = i
            while i < len(data) and data[i] not in [0x14, 0x15, 0x00]:
                i += 1
            
            if i >= len(data):
                break
            
            try:
                onset_str = data[onset_start:i].decode('ascii', errors='ignore')
                onset_seconds = float(onset_str)
                onset = int(onset_seconds * EDFLIB_TIME_DIMENSION)
            except (ValueError, UnicodeDecodeError):
                onset = 0
                onset_seconds = 0.0
            
            # Check for duration (0x15)
            duration = -1
            duration_seconds = None
            if i < len(data) and data[i] == 0x15:
                i += 1
                dur_start = i
                while i < len(data) and data[i] not in [0x14, 0x00]:
                    i += 1
                try:
                    dur_str = data[dur_start:i].decode('ascii', errors='ignore')
                    duration_seconds = float(dur_str)
                    duration = int(duration_seconds * EDFLIB_TIME_DIMENSION)
                except (ValueError, UnicodeDecodeError):
                    pass
            
            # Parse annotations separated by 0x14
            while i < len(data) and data[i] == 0x14:
                i += 1
                
                # Find annotation text
                annot_start = i
                while i < len(data) and data[i] not in [0x14, 0x00]:
                    i += 1
                
                if i > annot_start:
                    try:
                        description = data[annot_start:i].decode('utf-8', errors='replace')
                    except UnicodeDecodeError:
                        description = data[annot_start:i].decode('latin-1', errors='replace')
                    
                    desc_norm = normalize_annotation_text(description)
                    empty = is_annotation_empty(description)
                    
                    annotations.append(EDFAnnotation(
                        onset=onset,
                        onset_seconds=onset_seconds,
                        duration=duration,
                        duration_seconds=duration_seconds,
                        description=description,
                        description_normalized=desc_norm,
                        is_empty=empty,
                        block_position=position,
                    ))
            
            # Skip to next TAL
            while i < len(data) and data[i] == 0:
                i += 1
        
        return annotations
    
    def _read_ascii(self, data: bytes) -> str:
        """Read ASCII string from bytes, stripping nulls and spaces."""
        return data.decode('ascii', errors='ignore').strip(' \x00')
    
    def _parse_datetime(self, date_str: str, time_str: str) -> Optional[datetime]:
        """
        Parse EDF date and time strings into datetime.
        
        Args:
            date_str: Date in dd.mm.yy format
            time_str: Time in hh.mm.ss format
            
        Returns:
            datetime object or None if parsing fails
        """
        try:
            # Parse date (dd.mm.yy)
            date_parts = date_str.replace('.', '-').replace('/', '-').split('-')
            if len(date_parts) != 3:
                return None
            
            day = int(date_parts[0])
            month = int(date_parts[1])
            year = int(date_parts[2])
            
            # Handle 2-digit year
            if year < 85:
                year += 2000
            elif year < 100:
                year += 1900
            
            # Parse time (hh.mm.ss)
            time_parts = time_str.replace('.', ':').split(':')
            if len(time_parts) != 3:
                return None
            
            hour = int(time_parts[0])
            minute = int(time_parts[1])
            second = int(time_parts[2])
            
            return datetime(year, month, day, hour, minute, second)
            
        except (ValueError, IndexError):
            return None


def read_edf_annotations(file_path: str, max_annotations: int = -1) -> AnnotationReadResult:
    """
    Convenience function to read annotations from an EDF file.
    
    Args:
        file_path: Path to EDF/BDF file
        max_annotations: Maximum annotations to read (-1 for all)
        
    Returns:
        AnnotationReadResult
    """
    with EDFAnnotationReader(file_path) as reader:
        return reader.read(max_annotations)
