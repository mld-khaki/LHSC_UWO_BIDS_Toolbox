#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
edf_annot_utils.py

Utility functions for EDF annotation extraction tool.
Includes time conversion, text normalization, and logging helpers.

Author: Claude (based on patterns from edfreader by Teunis van Beelen / Milad Khaki)
"""

from __future__ import annotations

import os
import re
import logging
from datetime import datetime
from typing import Any, Optional

# EDF time dimension constant (100 nanoseconds)
EDFLIB_TIME_DIMENSION = 10000000


def onset_to_seconds(onset: int) -> float:
    """
    Convert onset from EDF time units (100 nanoseconds) to seconds.
    
    Args:
        onset: Onset time in 100 nanosecond units
        
    Returns:
        Onset time in seconds
    """
    return onset / EDFLIB_TIME_DIMENSION


def duration_to_seconds(duration: int) -> Optional[float]:
    """
    Convert duration from EDF time units to seconds.
    Returns None if duration is -1 (unspecified).
    
    Args:
        duration: Duration in 100 nanosecond units, or -1 if not specified
        
    Returns:
        Duration in seconds, or None if unspecified
    """
    if duration < 0:
        return None
    return duration / EDFLIB_TIME_DIMENSION


def format_onset_hhmmss(onset_seconds: float) -> str:
    """
    Format onset time as HH:MM:SS.mmm string.
    
    Args:
        onset_seconds: Onset time in seconds
        
    Returns:
        Formatted time string
    """
    total_ms = int(onset_seconds * 1000)
    hours = total_ms // 3600000
    remaining = total_ms % 3600000
    minutes = remaining // 60000
    remaining = remaining % 60000
    seconds = remaining // 1000
    milliseconds = remaining % 1000
    
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}.{milliseconds:03d}"


def normalize_annotation_text(text: str) -> str:
    """
    Normalize annotation text for comparison and display.
    Handles various newline encodings and escape sequences.
    
    Args:
        text: Raw annotation text
        
    Returns:
        Normalized text
    """
    if text is None:
        return ""
    
    s = str(text)
    
    # Decode literal escape markers (from ENT-style exports)
    s = s.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n")
    s = s.replace("\\x0d", "\n").replace("\\x0a", "\n").replace("\\xd", "\n")
    
    # Normalize actual newlines
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    
    return s


def is_annotation_empty(description: str) -> bool:
    """
    Check if an annotation description is effectively empty.
    Empty means: None, empty string, or only whitespace/control characters.
    
    Args:
        description: Annotation description text
        
    Returns:
        True if the annotation is considered empty
    """
    if description is None:
        return True
    
    # Normalize and strip
    normalized = normalize_annotation_text(description)
    stripped = normalized.strip()
    
    # Check if only whitespace or control characters remain
    if not stripped:
        return True
    
    # Check if only null bytes or control characters
    if all(ord(c) < 32 or ord(c) == 127 for c in stripped):
        return True
    
    return False


def sanitize_for_tsv(text: str) -> str:
    """
    Sanitize text for TSV output (escape tabs, newlines).
    
    Args:
        text: Input text
        
    Returns:
        Sanitized text safe for TSV
    """
    if text is None:
        return ""
    
    s = str(text)
    # Replace tabs with spaces
    s = s.replace("\t", " ")
    # Replace newlines with literal \n for readability
    s = s.replace("\r\n", "\\n").replace("\n", "\\n").replace("\r", "\\n")
    
    return s


def get_relative_path(file_path: str, base_path: str) -> str:
    """
    Get the relative path of a file from a base directory.
    
    Args:
        file_path: Full path to the file
        base_path: Base directory path
        
    Returns:
        Relative path from base to file
    """
    file_path = os.path.normpath(os.path.abspath(file_path))
    base_path = os.path.normpath(os.path.abspath(base_path))
    
    try:
        return os.path.relpath(file_path, base_path)
    except ValueError:
        # Different drives on Windows
        return file_path


def create_output_path(input_file: str, input_base: str, output_base: str, suffix: str = "_annot.tsv") -> str:
    """
    Create output file path maintaining relative folder structure.
    
    Args:
        input_file: Input file path (e.g., /data/sub01/session1/file.edf)
        input_base: Base input directory (e.g., /data)
        output_base: Base output directory (e.g., /output)
        suffix: Suffix for output filename (default: _annot.tsv)
        
    Returns:
        Output file path (e.g., /output/sub01/session1/file_annot.tsv)
    """
    rel_path = get_relative_path(input_file, input_base)
    
    # Change extension
    base_name = os.path.splitext(rel_path)[0]
    output_rel = base_name + suffix
    
    return os.path.join(output_base, output_rel)


def ensure_directory(file_path: str) -> None:
    """
    Ensure the directory for a file path exists.
    
    Args:
        file_path: Path to a file
    """
    dir_path = os.path.dirname(file_path)
    if dir_path:
        os.makedirs(dir_path, exist_ok=True)


def setup_logger(log_file: str, name: str = "edf_annot_scanner") -> logging.Logger:
    """
    Set up a logger that writes to both file and returns log messages.
    
    Args:
        log_file: Path to log file
        name: Logger name
        
    Returns:
        Configured logger
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    
    # Remove existing handlers
    logger.handlers.clear()
    
    # File handler
    ensure_directory(log_file)
    fh = logging.FileHandler(log_file, mode='w', encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    
    # Format
    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    
    return logger


def format_file_size(size_bytes: int) -> str:
    """
    Format file size in human-readable format.
    
    Args:
        size_bytes: Size in bytes
        
    Returns:
        Formatted size string (e.g., "1.5 GB")
    """
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if abs(size_bytes) < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"


def get_timestamp() -> str:
    """Get current timestamp string for filenames."""
    return datetime.now().strftime("%Y%m%d_%H%M%S")
